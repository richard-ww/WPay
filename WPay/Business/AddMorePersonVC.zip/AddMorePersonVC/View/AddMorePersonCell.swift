//
//  AddMorePersonCell.swift
//  WPay
//
//  Created by WeiWei on 2017/10/30.
//  Copyright © 2017年 --. All rights reserved.
//

import UIKit

class AddMorePersonCell: UITableViewCell, UITextFieldDelegate, UIPickerViewDataSource,UIPickerViewDelegate {
    
    
    
    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var cardTypeTextField: UITextField!
    @IBOutlet weak var cardNumTextField: UITextField!
    @IBOutlet weak var birthTextField: UITextField!
    
    let dataArr = ["1","2","3","4","5"]
    
    lazy var cardTypePicker: UIPickerView = {
        
        let pickerView = UIPickerView()
        
        pickerView.dataSource = self
        pickerView.delegate = self
        
        return pickerView
    }()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.initSubviews()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func initSubviews() {
        
        self.nameTextField.delegate = self
        self.cardNumTextField.delegate = self
        
        self.cardTypeTextField.inputView = self.cardTypePicker
    }
}

extension AddMorePersonCell {
    
    // MARK:- textField
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        let oldStr = textField.text
        var newStr = (oldStr as NSString?)?.replacingCharacters(in: range, with: string)
        if textField == self.cardNumTextField {
            
            newStr = newStr?.replacingOccurrences(of: " ", with: "")
        }
        
        return true
    }
    
    @IBAction func ensureBtnClick(_ sender: Any) {
        
        if (self.nameTextField.text?.characters.count)! == 0 {
            
            Toast.show(title: "请输入您的姓名")
            return
        }
        else if (self.nameTextField.text?.characters.count)! < 2 {
            
            Toast.show(title: "请输入正确的姓名")
            return
        }
        if self.cardNumTextField.text?.characters.count == 0 {
            
            Toast.show(title: "请输入您的身份证号")
            return
        }
        
        let expression = "(\\d{14}|\\d{17})(\\d|[xX])$"
        let regex = try?NSRegularExpression.init(pattern: expression, options: .caseInsensitive)
        let numOfMatches = regex?.matches(in: self.cardNumTextField.text ?? "", options: NSRegularExpression.MatchingOptions(rawValue: 0), range: NSMakeRange(0, ((self.cardNumTextField.text ?? "")?.characters.count)!))
        
        if numOfMatches?.count == 0 {
            
            Toast.show(title: "请输入有效的身份证号")
            return
        }
        
        if (self.nameTextField.text?.length)! >= 2 && (self.idCardTextField.text?.length)! == 18{
            
            // check success
        }
    }
}

extension AddMorePersonCell {
    
    // MARK:- pickerView
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        
        return self.dataArr.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        return self.dataArr[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        print(self.dataArr[row])
    }
}
